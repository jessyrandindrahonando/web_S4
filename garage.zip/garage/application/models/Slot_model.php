<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Slot_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    public function countSlot(){
        $query=$this->db->get('slot');
        return $query->num_rows();
    }
}