<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    public function insertClient($numVoiture,$idTypeVoiture){
        $data = array(
            'numVoiture' =>$numVoiture,
            'idTypeVoiture' =>$idTypeVoiture
        );
        $this->db->insert('client', $data);
        $insert_id = $this->db->insert_id();
        $query = $this->db->get_where('client', array('id' => $insert_id));
        $client=$query->row_array();
        return $client['id'];
    }
    public function exist($num){
        $query = $this->db->get_where('client', array('numVoiture' => $num));
        if($query->num_rows()==0){
            return false;
        }
        return true;
    }
    public function check($num,$idType){
        if($this->exist($num)){
            $query = $this->db->get_where('client', array('numVoiture' => $num));
            $client=$query->row_array();
            if($client['idTypeVoiture']!=$idType){
                return false;
            }
            else{
                return $client['id'];
            }
        }
        else{
            $idClient=$this->insertClient($num,$idType);
            return $idClient;
        }
    }
}