<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class TypeService_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }
    public function getAll(){
        $query=$this->db->get('typeService');
        return $query->result_array();
    }
    public function getDuree($id){
        $query = $this->db->get_where('typeService', array('id' => $id));
        $result=$query->row_array();
        return $result['duree'];
    }
    public function dureeToDateTime($id){
        $duree=$this->getDuree($id);
    }
}