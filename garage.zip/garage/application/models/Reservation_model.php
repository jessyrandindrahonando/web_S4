<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reservation_model extends CI_Model {
    public function __construct() {
        parent::__construct();
        $this->load->model('TypeService_model');
        $this->load->model('Slot_model');
    }
    public function dateToTimestamp($date){
        return strtotime($date);
    }

    public function getDateFin($date,$idTypeService){
        $duree = $this->TypeService_model->getDuree($idTypeService);
        $dureeParts = explode(':', $duree);
        $dureeInSeconds = ($dureeParts[0] * 3600) + ($dureeParts[1] * 60) + (isset($dureeParts[2]) ? $dureeParts[2] : 0);
        $dateFin = $date + $dureeInSeconds;
        return $dateFin;
    }
    public function checkDisponibiliteSlot($date, $idTypeService, $idSlot) {    
        $date = $this->dateToTimestamp($date);
        $dateFin = $this->getDateFin($date,$idTypeService);
        $this->db->where('idSlot', $idSlot);
        $this->db->where('dhDebut >=', date('Y-m-d H:i:s', $date));
        $this->db->where('dhFin <=', date('Y-m-d H:i:s', $dateFin));
        $query = $this->db->get('appointment');
        $result = $query->result_array();
        echo $this->db->last_query();

        if (count($result) == 0) {
            return true;
        }
        return false;
    }
    public function checkDisponibilite($date,$idTypeService){
        $nbSlot=$this->Slot_model->countSlot();
        $i=1;
        while($i<=$nbSlot){
            if($this->checkDisponibiliteSlot($date,$idTypeService,$i)){
                return $i;
            }
            $i++;
        }
        return false;
    }
    public function makeReservation($idClient,$idSlot,$idTypeService,$dhDebut,$dhFin){
        $data = array(
            'idClient' =>$idClient,
            'idSlot' =>$idTypeService,
            'idTypeService'=>$idTypeService,
            'dhDebut'=>$dhDebut,
            'dhFin'=>$dhFin
        );
        $this->db->insert('appointment', $data);
    }
}