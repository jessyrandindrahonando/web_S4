<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reservation_controller extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('TypeService_model');
        $this->load->model('Reservation_model');

    }
    public function index(){
        $data['contents']='reservation';
        $lsService=$this->TypeService_model->getAll();
        $data['contents']='reservation';
        $data['typesServices']=$lsService;
        $this->load->view('templates_login/template',$data);
    }
    public function traitement(){
        echo("test"."<br>");
        $date=$this->input->post('date');
        $idService=$this->input->post('service');
        $dt = $this->Reservation_model->dateToTimestamp($date);
        echo(date('Y-m-d H:i:s', $dt));
        echo('<br>');
        $dhDebut=date('Y-m-d H:i:s', $dt);
        $dateFin=$this->Reservation_model->getDateFin($dt,$idService);
        echo(date('Y-m-d H:i:s', $dateFin));
        
        if($this->Reservation_model->checkDisponibilite($date,$idService)){
            $idClient=$this->session->userdata('idClient');
            $idSlot=$this->Reservation_model->checkDisponibilite($date,$idService);
            $dhFin=date('Y-m-d H:i:s',$this->Reservation_model->getDateFin($dt,$idService));
            $this->Reservation_model->makeReservation($idClient,$idSlot,$idService,$dhDebut,$dhFin);
        }
        else{
            echo("tsy mety");
        }
    }
}