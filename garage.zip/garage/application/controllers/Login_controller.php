<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_controller extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Client_model');
        $this->load->model('TypeVoiture_model');

    }
    public function index(){
        $lsType=$this->TypeVoiture_model->getAll();
        $data['contents']='login';
        $data['typesVoitures']=$lsType;
        $this->load->view('templates_login/template',$data);
    }
    public function check(){
        $this->form_validation->set_rules('num', 'numéro voiture','required|callback_useCheck');
        $this->form_validation->set_rules('type', 'type voiture','required');
        if ($this->form_validation->run() == FALSE){
            $lsType=$this->TypeVoiture_model->getAll();
            $data['typesVoitures']=$lsType;
            $data['contents']='login';
            $this->load->view('templates_login/template',$data);
        }
        else{
            $num=$this->input->post('num');
            $idType=$this->input->post('type');
            $idClient=$this->Client_model->check($num,$idType);
            $this->session->set_userdata("idClient",$idClient);
            $data['contents']='accueil';
            $this->load->view('templates_front/template',$data);
        }
    }
    public function useCheck($num,$idType){
        $num=$this->input->post('num');
        $idType=$this->input->post('type');
        $idClient=$this->Client_model->check($num,$idType);
        if($idClient==false){
            $this->form_validation->set_message('useCheck', 'Le type de voiture de ce numéro est incorrect');
            return false;
        }
        return true;
    }
}