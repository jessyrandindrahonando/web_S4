<style>
    .erreur{
        color:red;
    }
</style>
<h1>Bienvenue dans notre garage</h1>
<?php echo form_open('Login_controller/check'); ?>
    <label>Numéro voiture</label>
    <input type="text" name="num" value="<?php echo set_value('num'); ?>"/>
    <br><br>
    <label>Type voiture</label>
    <select name="type">
        <option value="">Choisir un type</option>
        <?php foreach($typesVoitures as $typeVoiture): ?>
            <option value="<?php echo($typeVoiture['id']); ?>"<?php echo set_select('type', $typeVoiture['id']); ?>><?php echo($typeVoiture['nom']); ?></option>
        <?php endforeach; ?>
    </select>
    <br><br>
    <div><input type="submit" value="Valider" /></div>
    <div class="erreur"><?php echo validation_errors(); ?></div>
</form>