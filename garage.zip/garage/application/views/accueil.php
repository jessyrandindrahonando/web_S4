<h1>Accueil</h1>
<?php echo($this->session->userdata('idClient'));?>
<a href="<?php echo base_url('Reservation_controller/index'); ?>">Faire une réservation</a>