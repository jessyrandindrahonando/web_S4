<?php echo(count($typesServices)); ?>
    <?php echo($this->session->userdata('idClient'));?>
<h1>Faites un rendez-vous</h1>
<?php echo form_open('Reservation_controller/traitement'); ?>
    <label>Date et heure rendez-vous</label>
    <input type="datetime-local" name="date">
    <br><br>
    <label>Choisir le type de service</label>
    <select name="service">
        <option value="">Choisir un type</option>
        <?php foreach($typesServices as $typeService): ?>
            <option value="<?php echo($typeService['id']); ?>"<?php echo set_select('service', $typeService['id']); ?>><?php echo($typeService['nom']); ?></option>
        <?php endforeach; ?>
    </select>
    <br><br>
    <div><input type="submit" value="Valider" /></div>
</form>