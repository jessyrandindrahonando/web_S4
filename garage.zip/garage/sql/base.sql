create database garage;
use garage;

create table slot(
    id int primary key auto_increment,
    symbole varchar(1) 
);

create table typeService(
    id int primary key auto_increment,
    nom varchar(30),
    duree time,
    prix double precision
);

create table typeVoiture(
    id int primary key auto_increment,
    nom varchar(10)
);

create table client(
    id int primary key auto_increment,
    numVoiture varchar(30) unique,
    idTypeVoiture int,
    foreign key(idTypeVoiture) references typeVoiture(id)
);

create table appointment(
    id int primary key auto_increment,
    idClient int,
    idSlot int,
    idTypeService int,
    dhDebut timestamp,
    dhFin timestamp,
    foreign key(idClient) references client(id),
    foreign key(idSlot) references slot(id),
    foreign key(idTypeService) references typeService(id)
);

select * from appointment where dhDebut BETWEEN '2024-08-05 09:00:00' AND '2024-08-05 10:00:00' or dhFin BETWEEN '2024-08-05 09:00:00' AND '2024-08-05 10:00:00';

SELECT * 
FROM appointment
WHERE dhDebut >= '2024-08-05 09:00:00'
  AND dhFin <= '2024-08-05 10:00:00'
  AND idSlot=1;