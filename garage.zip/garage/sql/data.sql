INSERT INTO slot(symbole) VALUES 
    ('A'),
    ('B'),
    ('C');

INSERT INTO typeService(nom, duree, prix) VALUES
    ('simple', "01:00:00", 150000 ),
    ('standard', "02:00:00", 250000 ),
    ('complexe', "08:00:00", 800000 ),
    ('entretien', "02:30:00", 300000 );

INSERT INTO typeVoiture (nom) VALUES
    ('legere'),
    ('4*4'),
    ('utilitaire');

INSERT INTO client(numVoiture,idTypeVoiture) VALUES
    (123,1);


INSERT INTO client(numVoiture, idTypeVoiture) VALUES
    ('AAAA', 1),
    ('BBBB', 2),
    ('CCCC', 3),
    ('DDDD', 1),
    ('EEEE', 2),
    ('FFFF', 3),
    ('GGGG', 1),
    ('HHHH', 2);



-- Insertion de données de test avec des rendez-vous simultanés mais dans des slots différents
INSERT INTO appointment (idClient, idSlot, idTypeService, dhDebut, dhFin) VALUES
    -- Rendez-vous pour service simple, durée de 1 heure
    (1, 1, 1, '2024-08-05 08:00:00', '2024-08-05 09:00:00'),  -- Client 1, Slot A, Service Simple (1 heure)
    
    -- Rendez-vous pour service standard, durée de 2 heures (simultané avec le rendez-vous précédent mais dans un autre slot)
    (2, 2, 2, '2024-08-05 08:30:00', '2024-08-05 10:30:00'),  -- Client 2, Slot B, Service Standard (2 heures)
    
    -- Rendez-vous pour service complexe, durée de 8 heures (créneau complet)
    (3, 3, 3, '2024-08-05 08:00:00', '2024-08-05 16:00:00'),  -- Client 3, Slot C, Service Complexe (8 heures)
    
    -- Rendez-vous pour service entretien, durée de 2 heures 30 minutes (simultané avec le précédent)
    (4, 1, 4, '2024-08-05 10:00:00', '2024-08-05 12:30:00'),  -- Client 4, Slot A, Service Entretien (2 heures 30 minutes)
    
    -- Rendez-vous pour service simple, durée de 1 heure
    (5, 2, 1, '2024-08-05 09:00:00', '2024-08-05 10:00:00'),  -- Client 5, Slot B, Service Simple
    
    -- Rendez-vous pour service standard, durée de 2 heures
    (6, 3, 2, '2024-08-05 13:00:00', '2024-08-05 15:00:00'),  -- Client 6, Slot C, Service Standard (simultané avec le rendez-vous de Client 4)
    
    -- Rendez-vous pour service complexe, durée de 8 heures (simultané avec les autres créneaux du même jour)
    (7, 2, 3, '2024-08-05 11:00:00', '2024-08-05 19:00:00');  -- Client 7, Slot B, Service Complexe
